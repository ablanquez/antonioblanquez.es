# Plan: modelo visual de antonioblanquez.es

## Alcance
- Pantallas: una portada y una plantilla única de proyecto, que se aplica a los 4 proyectos. Son 5 pantallas, cada una en 3 tamaños: 1280, 820 y 390 px.
- Solo es un modelo visual con datos estáticos: sin backend, sin API, sin almacenamiento y sin formulario.
- El contenido es literal, el de guidelines.md. Donde falte texto se pondrá «[texto pendiente]».
- No se añade nada que no se pida.
- Terminado significa: pantallas que se puedan copiar como capas de diseño, con nombres de capa semánticos en español.

## 1. Componentes reutilizados
| Capa | Contenido | Dónde |
|---|---|---|
| Saltar al contenido | Enlace «Saltar al contenido», visible al recibir foco, que lleva a «Contenido principal» | Ambas |
| Cabecera | Nombre (enlace a la portada) + Navegación principal | Ambas |
| Navegación principal | Los 4 enlaces; en móvil, Botón «Menú» (44 px) que despliega la Lista de navegación | Ambas |
| Navegación final | Los mismos 4 enlaces, repetidos al final de la página, antes del pie | Ambas |
| Sección | Contenedor con ancho máximo, márgenes y Título de sección | Ambas |
| Bloque de texto | Titulares, párrafos y listas | Ambas |
| Enlace de acción | Estados normal, foco y pulsado | Ambas |
| Pie | «© 2026 Antonio Blánquez» + enlaces «Aviso legal», «Privacidad» y «Condiciones» | Ambas |
| Tokens | Color, tipografía y espaciado (base provisional, en un solo fichero) | Global |
| Contenido | Fichero de datos con el texto literal y los 4 proyectos | Global |

- Exclusivo de la portada:
  - Presentación.
  - Lista de proyectos, formada por 4 Tarjetas de proyecto, sin imagen. Cada tarjeta lleva:
    - Nombre del proyecto.
    - Texto del proyecto, literal de guidelines.md.
    - Enlace «En vivo»; en Linaje, «Demo en vivo».
    - Enlace «Código».
  - Contacto: sección propia con email, LinkedIn y GitHub, como enlaces y sin formulario. El contacto no va en el pie.
  - El orden de las secciones lo fija guidelines.
- Exclusivo de la página de proyecto: Cabecera del proyecto y Cuerpo del proyecto.

## 2. Cambios entre tamaños
| Elemento | Escritorio 1280 | Tableta 820 | Móvil 390 |
|---|---|---|---|
| Márgenes / ancho máx. | 80 px / 1120 px | 40 px | 20 px |
| Navegación principal | horizontal | horizontal, enlaces de 44 px | Botón «Menú» de 44 px; despliega los 4 enlaces apilados, de 44 px; capas: Menú cerrado y Menú abierto |
| Navegación final | 4 enlaces en fila | en fila, 44 px | apilados, 44 px |
| Tarjetas de proyecto | 2 columnas | 1 columna | 1 columna |
| Contacto (portada) | enlaces en fila | en fila, 44 px | apilados, 44 px |
| Página de proyecto | columna única, texto con máx. 66 caracteres por línea | igual | igual (ancho disponible) |
| Pie | copyright y enlaces en una línea | igual, enlaces de 44 px | apilado, 44 px |

En todos los tamaños:
- Sin scroll horizontal a 320 px.
- Contraste AA y foco visible.

## 3. Orden de construcción
1. Volcar guidelines.md, de forma literal, en Tokens y Contenido.
2. Construir los componentes base: Saltar al contenido, Cabecera con Navegación (incluido el Botón «Menú»), Navegación final, Sección, Bloque de texto, Enlace de acción y Pie.
3. Hacer la portada, primero en móvil y luego en tableta y escritorio, incluida la sección Contacto.
4. Hacer la plantilla de proyecto, de columna única con 66 caracteres como máximo, en los 3 tamaños, y rellenarla con los 4 proyectos.
5. Preparar una vista de presentación con marcos de 1280, 820 y 390 px por pantalla; en móvil se muestran el menú cerrado y el menú abierto.
6. Verificar:
   - contraste AA, foco, 44 px y ausencia de scroll a 320 px;
   - que no aparece ningún efecto prohibido;
   - que no se ha añadido contenido;
   - que todas las capas tienen nombre semántico en español.
