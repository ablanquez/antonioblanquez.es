import { useEffect, useRef, useState, type CSSProperties } from "react"
import { capa, Pagina } from "./Comunes"
import {
  comoTrabajo,
  contacto,
  propietario,
  proyectos,
  sobreMi,
} from "./contenido"

const Presentacion = capa("presentacion", "section")
const Proyectos = capa("proyectos", "section")
const TarjetaProyecto = capa("tarjeta-proyecto", "li")
const ComoTrabajo = capa("como-trabajo", "section")
const SobreMi = capa("sobre-mi", "section")
const Contacto = capa("contacto", "section")
const Foto = capa("foto", "div")

/** Rótulo de etapa («2007-2012 · DFA»): los años van en <time>; el texto no cambia. */
function RotuloEtapa({ rotulo }: { rotulo: string }) {
  const desde = rotulo.match(/^(Desde )(\d{4})(.*)$/)
  if (desde)
    return (
      <>
        {desde[1]}
        <time dateTime={desde[2]}>{desde[2]}</time>
        {desde[3]}
      </>
    )
  const m = rotulo.match(/^(\d{4})-(\d{4})(.*)$/)
  if (!m) return <>{rotulo}</>
  return (
    <>
      <time dateTime={m[1]}>{m[1]}</time>-<time dateTime={m[2]}>{m[2]}</time>
      {m[3]}
    </>
  )
}

/** Iconos de «Cómo trabajo» (equivalentes a lucide-react Search, MonitorSmartphone,
    Code, ListChecks, PackageCheck y ShieldCheck). Decoración: el título del paso dice lo mismo. */
const trazoPaso = {
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": true,
  focusable: "false",
} as const
const iconosPasos = [
  <svg {...trazoPaso}>
    <circle cx="11" cy="11" r="8" />
    <path d="m21 21-4.3-4.3" />
  </svg>,
  <svg {...trazoPaso}>
    <path d="M18 8V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8" />
    <path d="M10 19v-3.96 3.15" />
    <path d="M7 19h5" />
    <rect width="6" height="10" x="16" y="12" rx="2" />
  </svg>,
  <svg {...trazoPaso}>
    <polyline points="16 18 22 12 16 6" />
    <polyline points="8 6 2 12 8 18" />
  </svg>,
  <svg {...trazoPaso}>
    <path d="m3 17 2 2 4-4" />
    <path d="m3 7 2 2 4-4" />
    <path d="M13 6h8" />
    <path d="M13 12h8" />
    <path d="M13 18h8" />
  </svg>,
  <svg {...trazoPaso}>
    <path d="m16 16 2 2 4-4" />
    <path d="M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14" />
    <path d="m7.5 4.27 9 5.15" />
    <polyline points="3.29 7 12 12 20.71 7" />
    <line x1="12" x2="12" y1="22" y2="12" />
  </svg>,
  <svg {...trazoPaso}>
    <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
    <path d="m9 12 2 2 4-4" />
  </svg>,
]

/** Globe (equivalente a lucide-react, que no está instalado). */
export function IconoGlobo() {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" />
      <path d="M2 12h20" />
    </svg>
  )
}

/** Marca de GitHub (Invertocat), de un solo color. */
export function IconoGitHub() {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 16 16"
      fill="currentColor"
      aria-hidden="true"
    >
      <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z" />
    </svg>
  )
}

/** Sobre (equivalente a lucide-react Mail). */
function IconoSobre() {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
    </svg>
  )
}

/** Descarga (equivalente a lucide-react Download). */
function IconoDescarga() {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <path d="m7 10 5 5 5-5" />
      <path d="M12 15V3" />
    </svg>
  )
}

/** Logo de LinkedIn, de un solo color. */
export function IconoLinkedIn() {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
    >
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 1 1 0-4.125 2.062 2.062 0 0 1 0 4.125zM7.119 20.452H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  )
}

/** Flecha de enlace externo (equivalente a lucide-react ArrowUpRight). */
function IconoFlechaFuera() {
  return (
    <svg
      className="canal-flecha"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      <path d="M7 7h10v10" />
      <path d="M7 17 17 7" />
    </svg>
  )
}

/** Dirección web que solo puede partir tras la última «/» (p. ej. «linkedin.com/in/» · «antonioblanquez»). */
function DireccionPartible({ texto }: { texto: string }) {
  const i = texto.lastIndexOf("/") + 1
  if (i <= 0) return <>{texto}</>
  return (
    <>
      {texto.slice(0, i)}
      <wbr />
      {texto.slice(i)}
    </>
  )
}

/** «Contacto» de la portada: tarjeta de visita (prueba pendiente de firma). */
function TarjetaVisita() {
  const c = contacto
  const [estado, setEstado] = useState<"" | "ok" | "fallo">("")
  const [anuncio, setAnuncio] = useState("")
  const temporizador = useRef<number | undefined>(undefined)
  useEffect(() => () => window.clearTimeout(temporizador.current), [])
  const copiar = async () => {
    window.clearTimeout(temporizador.current)
    try {
      if (!navigator.clipboard) throw new Error("sin portapapeles")
      await navigator.clipboard.writeText(c.correo.dato)
      setEstado("ok")
      setAnuncio(c.correo.anuncioCopiado)
    } catch {
      setEstado("fallo")
      setAnuncio(c.correo.fallo)
    }
    temporizador.current = window.setTimeout(() => {
      setEstado("")
      setAnuncio("")
    }, 2000)
  }
  return (
    <div className="tarjeta-visita">
      <div className="cuerpo">
        <div className="visita-quien">
          <p className="visita-nombre">{c.nombre}</p>
          {/* Hueco de la foto (marcador); la foto irá aquí con alt="". */}
          <div className="visita-foto" aria-hidden="true">
            [foto]
          </div>
          <p className="visita-rol">{c.rol}</p>
          <div className="visita-abajo">
            <p className="visita-lugar">{c.lugar}</p>
            {/* Número y unidad juntos («24 horas»); el texto que se lee no cambia. */}
            <p className="visita-respuesta">
              {c.entrada.replace("24 horas", "24\u00A0horas")}
            </p>
          </div>
        </div>
        <ul className="visita-canales" role="list">
          <li className="canal canal-correo">
            <div className="canal-fila">
              <span className="canal-icono">
                <IconoSobre />
              </span>
              <span className="canal-texto">
                <span className="canal-nombre">{c.correo.canal}</span>
                <span className="canal-dato">{c.correo.dato}</span>
              </span>
            </div>
            <div className="canal-botones">
              <a
                className="boton-primario"
                href={`mailto:${propietario.email}`}
              >
                {c.correo.escribir}
              </a>
              <button type="button" className="boton-copiar" onClick={copiar}>
                {estado === "ok"
                  ? c.correo.copiado
                  : estado === "fallo"
                    ? c.correo.fallo
                    : c.correo.copiar}
              </button>
            </div>
            <p className="sr-only" role="status">
              {anuncio}
            </p>
          </li>
          <li className="canal">
            <a
              className="canal-fila canal-enlace"
              href={propietario.linkedin}
              aria-label={`${c.linkedin.canal}: ${c.linkedin.dato}`}
            >
              <span className="canal-icono canal-logo">
                <IconoLinkedIn />
              </span>
              <span className="canal-texto">
                <span className="canal-nombre">{c.linkedin.canal}</span>
                <span className="canal-dato">
                  <DireccionPartible texto={c.linkedin.dato} />
                </span>
              </span>
              <IconoFlechaFuera />
            </a>
          </li>
          <li className="canal">
            <a
              className="canal-fila canal-enlace"
              href={propietario.github}
              aria-label={`${c.github.canal}: ${c.github.dato}`}
            >
              <span className="canal-icono canal-logo">
                <IconoGitHub />
              </span>
              <span className="canal-texto">
                <span className="canal-nombre">{c.github.canal}</span>
                <span className="canal-dato">
                  <DireccionPartible texto={c.github.dato} />
                </span>
              </span>
              <IconoFlechaFuera />
            </a>
          </li>
        </ul>
      </div>
    </div>
  )
}

function EnlacesContacto({
  boton = false,
  iconos = false,
  marcas = false,
}: {
  boton?: boolean
  iconos?: boolean
  marcas?: boolean
}) {
  if (marcas)
    return (
      <ul
        className="botones-tarjeta botones-contacto"
        data-name="enlaces-contacto"
      >
        <li>
          <a className="boton-primario" href={`mailto:${propietario.email}`}>
            <IconoSobre />
            Escríbeme
          </a>
        </li>
        <li>
          <a
            className="boton-secundario boton-marca boton-cuadrado"
            href={propietario.linkedin}
          >
            <IconoLinkedIn />
            <span className="sr-only">LinkedIn</span>
          </a>
        </li>
        <li>
          <a
            className="boton-secundario boton-marca boton-cuadrado"
            href={propietario.github}
          >
            <IconoGitHub />
            <span className="sr-only">GitHub</span>
          </a>
        </li>
      </ul>
    )
  if (iconos)
    return (
      <ul
        className="botones-tarjeta botones-contacto"
        data-name="enlaces-contacto"
      >
        <li>
          <a className="boton-primario" href={`mailto:${propietario.email}`}>
            <IconoSobre />
            Escríbeme
          </a>
        </li>
        <li>
          <a className="boton-secundario" href={propietario.linkedin}>
            <IconoLinkedIn />
            LinkedIn
          </a>
        </li>
        <li>
          <a className="boton-secundario" href={propietario.github}>
            <IconoGitHub />
            GitHub
          </a>
        </li>
      </ul>
    )
  return (
    <ul className="enlaces-fila" data-name="enlaces-contacto">
      <li>
        {boton ? (
          <a className="boton-contacto" href={`mailto:${propietario.email}`}>
            Escríbeme
          </a>
        ) : (
          <a href={`mailto:${propietario.email}`}>{propietario.email}</a>
        )}
      </li>
      <li>
        <a href={propietario.linkedin}>LinkedIn</a>
      </li>
      <li>
        <a href={propietario.github}>GitHub</a>
      </li>
    </ul>
  )
}

export default function Portada({
  p,
  menuAbierto = false,
  conVida = false,
  detalles = false,
  detalles2 = false,
  detalles3 = false,
  inicio = false,
  /** Solo en /con-vida: foto, capturas, botón de contacto y banda. */
  /** Solo en /detalles: botones con icono y captura en contenedor recortado. */
  /** Solo en /detalles-2: barra sobre la captura, móvil, contacto con iconos. */
  /** /detalles-3: frase corta como h1, zona de captura clicable y nombre en color con flecha. */
  /** Portada /: lo de /detalles-3 más la Decisión 7 (logos neutros, contacto con cuadrados). */
}: {
  p: string
  menuAbierto?: boolean
  conVida?: boolean
  detalles?: boolean
  detalles2?: boolean
  detalles3?: boolean
  inicio?: boolean
}) {
  return (
    <Pagina
      p={p}
      base=""
      menuAbierto={menuAbierto}
      inicio={inicio}
      sitio={inicio}
    >
      {conVida ? (
        inicio ? (
          /* Portada /: orden del DOM titular · foto · texto · botones (WCAG 1.3.2) */
          <Presentacion className="presentacion presentacion-con-foto presentacion-texto presentacion-ordenada">
            <h1 className="frase-corta">{propietario.fraseCorta}</h1>
            <Foto className="foto">[foto pendiente]</Foto>
            <p className="texto">{propietario.fraseLarga}</p>
            <EnlacesContacto boton iconos={detalles2} marcas={inicio} />
          </Presentacion>
        ) : (
        <Presentacion className="presentacion presentacion-con-foto">
          <Foto className="foto">[foto pendiente]</Foto>
          <div className="presentacion-texto">
            {detalles3 ? (
              <h1 className="frase-corta">{propietario.fraseCorta}</h1>
            ) : (
              <>
                <h1>{propietario.nombre}</h1>
                <p className="frase-corta">{propietario.fraseCorta}</p>
              </>
            )}
            <p className="texto">{propietario.fraseLarga}</p>
            <EnlacesContacto boton iconos={detalles2} marcas={inicio} />
          </div>
        </Presentacion>
        )
      ) : (
        <Presentacion className="presentacion">
          <h1>{propietario.nombre}</h1>
          <p className="frase-corta">{propietario.fraseCorta}</p>
          <p className="texto">{propietario.fraseLarga}</p>
          <EnlacesContacto />
        </Presentacion>
      )}

      <Proyectos id={`${p}-proyectos`} aria-labelledby={`${p}-t-proyectos`}>
        <h2 id={`${p}-t-proyectos`}>Proyectos</h2>
        <ul className="rejilla">
          {proyectos.map((pr) => (
            <TarjetaProyecto
              key={pr.nombre}
              className="tarjeta"
              style={{
                borderTop: `4px solid var(--color-proyecto-${pr.slug})`,
              }}
            >
              {detalles2 ? (
                <div className="zona-captura" data-name="captura-proyecto">
                  <div className="barra-captura" data-name="barra-proyecto">
                    <img
                      className="icono"
                      src={pr.icono}
                      alt=""
                      width={32}
                      height={32}
                      data-name="icono-proyecto"
                    />
                    <h3>
                      <a
                        className="enlace-titulo"
                        href={`/proyectos/${pr.slug}`}
                        style={
                          detalles3
                            ? {
                                "--color-proyecto": `var(--color-proyecto-${pr.slug})`,
                              } as CSSProperties
                            : undefined
                        }
                      >
                        {pr.nombre}
                        {detalles3 && (
                          <svg
                            className="flecha"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth={2}
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            aria-hidden="true"
                          >
                            <path d="M7 17 17 7" />
                            <path d="M7 7h10v10" />
                          </svg>
                        )}
                      </a>
                    </h3>
                  </div>
                  <img
                    className="captura-escritorio"
                    src={pr.captura.src}
                    alt={pr.captura.alt}
                  />
                  <div className="marco-movil" data-name="captura-movil">
                    <img src={`/capturas/movil-${pr.slug}.png`} alt="" />
                  </div>
                </div>
              ) : null}
              {!detalles2 &&
                conVida &&
                (detalles ? (
                  <div className="captura-marco" data-name="captura-proyecto">
                    <img src={pr.captura.src} alt={pr.captura.alt} />
                  </div>
                ) : (
                  <img
                    className="captura-tarjeta"
                    src={pr.captura.src}
                    alt={pr.captura.alt}
                    data-name="captura-proyecto"
                  />
                ))}
              {!detalles2 && (
                <h3 className="titulo-con-icono">
                  <img
                    className="icono"
                    src={pr.icono}
                    alt=""
                    width={32}
                    height={32}
                    data-name="icono-proyecto"
                  />
                  <a className="enlace-titulo" href={`/proyectos/${pr.slug}`}>
                    {pr.nombre}
                  </a>
                </h3>
              )}
              <p className="texto">{pr.texto}</p>
              {detalles ? (
                <ul className="botones-tarjeta" data-name="botones-proyecto">
                  <li>
                    <a className="boton-primario" href={pr.enVivo}>
                      <IconoGlobo />
                      {pr.etiquetaEnVivo}
                    </a>
                  </li>
                  <li>
                    <a
                      className={
                        inicio
                          ? "boton-secundario boton-marca"
                          : "boton-secundario"
                      }
                      href={pr.codigo}
                    >
                      <IconoGitHub />
                      Código
                    </a>
                  </li>
                </ul>
              ) : (
                <ul className="enlaces-fila">
                  <li>
                    <a href={pr.enVivo}>{pr.etiquetaEnVivo}</a>
                  </li>
                  <li>
                    <a href={pr.codigo}>Código</a>
                  </li>
                </ul>
              )}
            </TarjetaProyecto>
          ))}
        </ul>
      </Proyectos>

      <ComoTrabajo
        id={`${p}-como-trabajo`}
        className={conVida ? "banda" : undefined}
      >
        <h2>Cómo trabajo</h2>
        {inicio ? (
          <>
            <p className="entrada-pasos">{comoTrabajo.entrada}</p>
            <ol className="pasos" role="list">
              {comoTrabajo.pasos.map((paso, i) => (
                <li key={paso.titulo} className="paso">
                  <span className="paso-icono">{iconosPasos[i]}</span>
                  <div className="paso-texto">
                    <h3>{paso.titulo}</h3>
                    <p>{paso.texto}</p>
                  </div>
                </li>
              ))}
            </ol>
          </>
        ) : (
          <p className="texto">[texto pendiente]</p>
        )}
      </ComoTrabajo>

      <SobreMi id={`${p}-sobre-mi`}>
        <h2>Sobre mí</h2>
        {inicio ? (
          <>
            <ol className="linea-tiempo" role="list">
              {sobreMi.etapas.map((etapa) => (
                <li key={etapa.rotulo} className="etapa">
                  <h3>
                    <span className="rotulo">
                      <RotuloEtapa rotulo={etapa.rotulo} />
                    </span>
                  </h3>
                  <p>{etapa.texto}</p>
                  <div className="cifras">
                    {etapa.cifras.map((c) => (
                      <p key={c.valor + c.etiqueta} className="ficha-cifra">
                        {/* Cuerpo aparte de la franja (::before) para poder desplegarlo. */}
                        <span className="cuerpo">
                          {/* El matiz siempre ocupa su línea; vacío, no se anuncia. */}
                          <span
                            className="matiz"
                            aria-hidden={c.matiz ? undefined : true}
                          >
                            {c.matiz}
                          </span>
                          {c.matiz && " "}
                          <span className="valor">{c.valor}</span>{" "}
                          <span className="etiqueta">{c.etiqueta}</span>
                        </span>
                      </p>
                    ))}
                  </div>
                </li>
              ))}
            </ol>
            <div className="tarjeta-cierre">
              {sobreMi.cierre.map((parrafo) => (
                <p key={parrafo} className="cierre">
                  {parrafo}
                </p>
              ))}
              <div className="botones-tarjeta">
                <a
                  className="boton-secundario boton-marca"
                  href="/cv-antonio-blanquez.pdf"
                  download
                >
                  <IconoDescarga />
                  Descargar CV (PDF)
                </a>
              </div>
            </div>
          </>
        ) : (
          <p className="texto">[texto pendiente]</p>
        )}
      </SobreMi>

      <Contacto id={`${p}-contacto`}>
        {/* Portada: el h2 sigue en el árbol de títulos, oculto a la vista. */}
        <h2 className={inicio ? "sr-only" : undefined}>Contacto</h2>
        {inicio ? (
          <TarjetaVisita />
        ) : (
          <EnlacesContacto boton={conVida} iconos={detalles2} marcas={inicio} />
        )}
      </Contacto>
    </Pagina>
  )
}
