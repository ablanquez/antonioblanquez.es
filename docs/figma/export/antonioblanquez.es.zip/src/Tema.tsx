import { useSyncExternalStore } from "react"

export type Tema = "claro" | "oscuro"

const consulta =
  typeof window !== "undefined" && "matchMedia" in window
    ? window.matchMedia("(prefers-color-scheme: dark)")
    : undefined
const sistema = (): Tema => (consulta?.matches ? "oscuro" : "claro")

function leerGuardado(): Tema | undefined {
  try {
    const v = window.localStorage.getItem("tema")
    return v === "claro" || v === "oscuro" ? v : undefined
  } catch {
    return undefined
  }
}

let guardado = leerGuardado()
let tema: Tema = guardado ?? sistema()
const oyentes = new Set<() => void>()
const avisar = () => oyentes.forEach((o) => o())

// Sin tema guardado, el tema sigue al sistema.
consulta?.addEventListener("change", () => {
  if (guardado) return
  sinTransiciones()
  tema = sistema()
  avisar()
})

/** El cambio de tema no anima colores: los marcos pierden las transiciones hasta el siguiente frame. */
function sinTransiciones() {
  const marcos = document.querySelectorAll(".marco")
  marcos.forEach((m) => m.classList.add("sin-transicion"))
  requestAnimationFrame(() =>
    requestAnimationFrame(() =>
      marcos.forEach((m) => m.classList.remove("sin-transicion")),
    ),
  )
}

export function alternarTema() {
  const nuevo: Tema = tema === "oscuro" ? "claro" : "oscuro"
  try {
    if (nuevo === sistema()) window.localStorage.removeItem("tema")
    else window.localStorage.setItem("tema", nuevo)
  } catch {
    /* sin almacenamiento: el cambio dura hasta recargar */
  }
  guardado = nuevo === sistema() ? undefined : nuevo
  sinTransiciones()
  tema = nuevo
  const aviso = document.getElementById("aviso-tema")
  if (aviso)
    aviso.textContent = nuevo === "oscuro" ? "Tema oscuro" : "Tema claro"
  avisar()
}

export function useTema(): Tema {
  return useSyncExternalStore(
    (o) => {
      oyentes.add(o)
      return () => oyentes.delete(o)
    },
    () => tema,
  )
}

/** Región única, fuera de los marcos, que anuncia el cambio de tema. */
export function AvisoTema() {
  return <div id="aviso-tema" className="aviso-tema" role="status" />
}

const trazo = {
  width: 20,
  height: 20,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": true,
} as const

function IconoTema({ t }: { t: Tema }) {
  return t === "oscuro" ? (
        <svg {...trazo}>
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41" />
        </svg>
      ) : (
        <svg {...trazo}>
          <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
        </svg>
      )
}

export function BotonTema() {
  const t = useTema()
  const etiqueta = t === 'oscuro' ? 'Cambiar a tema claro' : 'Cambiar a tema oscuro'
  return (
    <button type="button" className="boton-tema" aria-label={etiqueta} title={etiqueta} onClick={alternarTema} data-name="boton-tema">
      <IconoTema t={t} />
    </button>
  )
}

/** Muestra no interactiva del botón de tema (Piezas de /identidad). */
export function MuestraBotonTema() {
  const t = useTema()
  return (
    <span className="boton-tema" aria-hidden="true">
      <IconoTema t={t} />
    </span>
  )
}
