import { useEffect } from "react"
import Portada from "./Portada"
import PaginaProyecto from "./PaginaProyecto"
import { proyectos } from "./contenido"
import Identidad from "./Identidad"
import { AvisoTema, useTema } from "./Tema"

const marcosPortada = [
  { p: "escritorio", titulo: "Escritorio · 1280 px", ancho: 1280 },
  { p: "tableta", titulo: "Tableta · 820 px", ancho: 820 },
  { p: "movil", titulo: "Móvil · 390 px", ancho: 390 },
]

const marcosProyecto = marcosPortada.slice(0, 3)

/** Ruta de revisión del modo oscuro: portada y Desplázame en los tres tamaños. */
function ModoOscuro() {
  const desplazame = proyectos.find((pr) => pr.slug === "desplazame")!
  const filas = [
    { nombre: "Portada", clave: "portada" },
    { nombre: "Desplázame", clave: "desplazame" },
  ]
  return (
    <div className="lienzo-revision">
      {filas.map((f) => (
        <div key={f.clave}>
          <h2 className="etiqueta-fila">Oscuro · {f.nombre}</h2>
          <div className="lienzo">
            {marcosProyecto.map((m) => {
              const p = `oscuro-${f.clave}-${m.p}`
              return (
                <figure key={m.p} className="marco-figura">
                  <figcaption>{m.titulo}</figcaption>
                  <div
                    className="marco"
                    data-tema="oscuro"
                    style={{ width: m.ancho }}
                    data-name={`oscuro-${f.clave}-${m.p}`}
                  >
                    {f.clave === "portada" ? (
                      <Portada p={p} />
                    ) : (
                      <PaginaProyecto p={p} proyecto={desplazame} />
                    )}
                  </div>
                </figure>
              )
            })}
          </div>
        </div>
      ))}
    </div>
  )
}

/** Solo /detalles: carga la fuente de la firma y prepara la aparición al hacer scroll. */
function useDetalles(activo: boolean, version2 = false) {
  useEffect(() => {
    if (!activo) return
    const fuente = document.createElement("link")
    fuente.rel = "stylesheet"
    fuente.href = version2
      ? "https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap"
      : "https://fonts.googleapis.com/css2?family=Mrs+Saint+Delafield&display=swap"
    document.head.appendChild(fuente)

    const raiz = document.documentElement
    // Cada marco mide su propia cabecera y guarda --alto-cabecera en su .marco.
    let medidor: ResizeObserver | undefined
    if (version2 && "ResizeObserver" in window) {
      medidor = new ResizeObserver((entradas) => {
        for (const e of entradas) {
          const cabecera = e.target as HTMLElement
          cabecera
            .closest<HTMLElement>(".marco")
            ?.style.setProperty(
              "--alto-cabecera",
              `${cabecera.getBoundingClientRect().height}px`,
            )
        }
      })
      document
        .querySelectorAll<HTMLElement>(".detalles-2 .cabecera")
        .forEach((c) => medidor!.observe(c))
    }
    // Portada: el botón «Arriba» aparece cuando la presentación sale de la vista.
    let vigia: IntersectionObserver | undefined
    if ("IntersectionObserver" in window) {
      vigia = new IntersectionObserver((entradas) => {
        for (const e of entradas)
          e.target
            .closest(".marco")
            ?.classList.toggle("arriba-visible", !e.isIntersecting)
      })
      document
        .querySelectorAll(".inicio .presentacion")
        .forEach((s) => vigia!.observe(s))
      // Proyecto: «Arriba» solo cuando la composición ha quedado entera por encima de la vista.
      const vigiaProyecto = new IntersectionObserver((entradas) => {
        for (const e of entradas)
          e.target
            .closest(".marco")
            ?.classList.toggle(
              "arriba-visible",
              !e.isIntersecting && e.boundingClientRect.bottom <= 0,
            )
      })
      document
        .querySelectorAll(".proyecto [data-name='composicion']")
        .forEach((s) => vigiaProyecto.observe(s))
      const desconectar = vigia.disconnect.bind(vigia)
      vigia.disconnect = () => {
        desconectar()
        vigiaProyecto.disconnect()
      }
    }
    const reducido = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches
    if (reducido || !("IntersectionObserver" in window))
      return () => {
        vigia?.disconnect()
        medidor?.disconnect()
        fuente.remove()
      }

    const observador = new IntersectionObserver(
      (entradas) => {
        for (const e of entradas) {
          if (e.isIntersecting) {
            e.target.classList.add("revelado")
            observador.unobserve(e.target)
            // En /detalles-2, al terminar la aparición se quita su transición para que el hover vaya a 200 ms.
            if (version2) {
              const el = e.target as HTMLElement
              const fin = (ev: TransitionEvent) => {
                if (ev.target !== el || ev.propertyName !== "opacity") return
                el.removeEventListener("transitionend", fin)
                el.classList.remove("revelar", "revelado")
              }
              el.addEventListener("transitionend", fin)
            }
          }
        }
      },
      { threshold: 0.15 },
    )
    const selector = [
      ".portada main section:not(.presentacion) h2:not(.tarjeta-bloque h2)",
      ".tarjeta",
      "[data-name='como-trabajo'] > p",
      "[data-name='como-trabajo'] > .pasos",
      "[data-name='sobre-mi'] > p",
      "[data-name='sobre-mi'] > .linea-tiempo",
      "[data-name='sobre-mi'] > .tarjeta-cierre",
      "[data-name='contacto'] .enlaces-fila",
      "[data-name='contacto'] .botones-contacto",
      ".proyecto .aparece",
      ".proyecto [data-name='otros-proyectos'] .caja-proyecto",
    ].join(", ")
    document.querySelectorAll(".detalles").forEach((marco) => {
      marco.querySelectorAll<HTMLElement>(selector).forEach((el) => {
        el.classList.add("revelar")
        observador.observe(el)
      })
      // «Sobre mí»: las fichas de cada etapa se despliegan con la misma condición que revelar.
      // «Contacto»: la tarjeta de visita usa el mismo despliegue que las fichas.
      marco
        .querySelectorAll<HTMLElement>(
          ".cifras, [data-name='contacto'] .tarjeta-visita",
        )
        .forEach((el) => {
          el.classList.add("revelar-fichas")
          observador.observe(el)
        })
      marco.querySelectorAll<HTMLElement>(".tarjeta").forEach((t, i) => {
        t.style.setProperty(
          "--retraso",
          `calc(var(--escalon-aparicion) * ${i})`,
        )
      })
    })
    // El estado oculto solo se aplica cuando el script ya ha cargado.
    raiz.classList.add("js-revelar")
    return () => {
      observador.disconnect()
      raiz.classList.remove("js-revelar")
      vigia?.disconnect()
      medidor?.disconnect()
      fuente.remove()
    }
  }, [activo, version2])
}

export default function App() {
  const ruta = window.location.pathname.replace(/\/$/, "")
  if (ruta === "/modo-oscuro") return <ModoOscuro />
  const slug = ruta.match(/^\/proyectos\/([^/]+)$/)?.[1]
  const proyecto = slug ? proyectos.find((pr) => pr.slug === slug) : undefined

  const pagina = proyecto ? (
    <ProyectoSitio proyecto={proyecto} />
  ) : ruta === "/identidad" ? (
    <IdentidadSitio />
  ) : (
    <Inicio />
  )
  return (
    <>
      <AvisoTema />
      {pagina}
    </>
  )
}

/** /proyectos/*: Decisión 10. */
function ProyectoSitio({ proyecto }: { proyecto: typeof proyectos[number] }) {
  useDetalles(true, true)
  const tema = useTema()
  return (
    <div className="lienzo">
      {marcosProyecto.map((m) => (
        <figure key={m.p} className="marco-figura">
          <figcaption>{m.titulo}</figcaption>
          <div
            className="marco con-alma color-d detalles detalles-2 detalles-3 sitio proyecto"
            data-tema={tema}
            style={{ width: m.ancho }}
            data-name={`proyecto-${proyecto.slug}-${m.p}`}
          >
            <PaginaProyecto p={m.p} proyecto={proyecto} sitio />
          </div>
        </figure>
      ))}
    </div>
  )
}

/** Decisiones 8 y 9: marca en la cabecera y en la barra inferior de cada marco el enlace de la sección actual. */
function useSeccionActual() {
  useEffect(() => {
    if (!("IntersectionObserver" in window)) return
    const anclas = ["proyectos", "como-trabajo", "sobre-mi", "contacto"]
    const limpiezas: (() => void)[] = []
    const desbloqueos: (() => void)[] = []
    document.querySelectorAll<HTMLElement>(".marco.inicio").forEach((marco) => {
      const cabecera = marco.querySelector<HTMLElement>(".cabecera")
      const presentacion = marco.querySelector<HTMLElement>(".presentacion")
      const enlaces = [
        ...marco.querySelectorAll<HTMLAnchorElement>(
          ".cabecera .menu a, .barra-inferior a",
        ),
      ]
      const secciones = anclas
        .map((a) => marco.querySelector<HTMLElement>(`section[id$='-${a}']`))
        .filter((s): s is HTMLElement => !!s)
      if (!cabecera || !presentacion) return
      const enFranja = new Set<Element>()
      // Tras un clic, el enlace pulsado manda hasta que el usuario vuelva a desplazarse ('' = ninguno).
      let fijo: string | undefined
      const aplicar = (actual: string | undefined) =>
        enlaces.forEach((a) => {
          if (actual && a.hash === `#${actual}`)
            a.setAttribute("aria-current", "true")
          else a.removeAttribute("aria-current")
        })
      const marcar = () => {
        if (fijo !== undefined) return aplicar(fijo)
        let actual: string | undefined
        // «Contacto» solo cuando el final del marco ha llegado a la pantalla.
        if (marco.getBoundingClientRect().bottom <= window.innerHeight + 1)
          actual = secciones[secciones.length - 1]?.id
        else if (!enFranja.has(presentacion))
          actual = secciones.find((s) => enFranja.has(s))?.id
        aplicar(actual)
      }
      // Franja: del borde inferior de la cabecera fija al 40 % superior de la pantalla.
      let franja: IntersectionObserver | undefined
      let alto = -1
      const crearFranja = () => {
        const nuevo = Math.round(cabecera.getBoundingClientRect().height)
        if (nuevo === alto) return
        alto = nuevo
        franja?.disconnect()
        enFranja.clear()
        franja = new IntersectionObserver(
          (entradas) => {
            for (const e of entradas) {
              if (e.isIntersecting) enFranja.add(e.target)
              else enFranja.delete(e.target)
            }
            marcar()
          },
          { rootMargin: `-${alto}px 0px -60% 0px` },
        )
        ;[presentacion, ...secciones].forEach((s) => franja!.observe(s))
      }
      crearFranja()
      const medidor =
        "ResizeObserver" in window ? new ResizeObserver(crearFranja) : undefined
      medidor?.observe(cabecera)
      const alClic = (ev: MouseEvent) => {
        const a = (ev.target as Element).closest<HTMLAnchorElement>("a")
        if (!a || !marco.contains(a)) return
        if (enlaces.includes(a)) fijo = a.hash.slice(1)
        else if (a.matches("a.nombre, .arriba a")) fijo = ""
        else return
        marcar()
      }
      marco.addEventListener("click", alClic)
      // Llegar con el hash de una sección cuenta como un clic en su enlace (Decisión 10).
      const deLlegada = enlaces.find(
        (a) => a.hash && a.hash === window.location.hash,
      )
      if (deLlegada) {
        fijo = deLlegada.hash.slice(1)
        marcar()
      }
      window.addEventListener("scroll", marcar, { passive: true })
      desbloqueos.push(() => {
        if (fijo === undefined) return
        fijo = undefined
        marcar()
      })
      limpiezas.push(() => {
        franja?.disconnect()
        medidor?.disconnect()
        marco.removeEventListener("click", alClic)
        window.removeEventListener("scroll", marcar)
        enlaces.forEach((a) => a.removeAttribute("aria-current"))
      })
    })
    // Desplazamiento del usuario: rueda, gesto táctil o teclas que desplazan o mueven el foco.
    const teclas = [
      "ArrowUp",
      "ArrowDown",
      "ArrowLeft",
      "ArrowRight",
      "PageUp",
      "PageDown",
      "Home",
      "End",
      " ",
      "Tab",
    ]
    const desbloquear = () => desbloqueos.forEach((d) => d())
    const alTeclear = (ev: KeyboardEvent) => {
      if (teclas.includes(ev.key)) desbloquear()
    }
    window.addEventListener("wheel", desbloquear, { passive: true })
    window.addEventListener("touchmove", desbloquear, { passive: true })
    window.addEventListener("keydown", alTeclear)
    return () => {
      window.removeEventListener("wheel", desbloquear)
      window.removeEventListener("touchmove", desbloquear)
      window.removeEventListener("keydown", alTeclear)
      limpiezas.forEach((l) => l())
    }
  }, [])
}

/** Al llegar a /#<marco>-<sección> desde una página de proyecto, baja al ancla cuando la portada ya está montada. */
function useAnclaInicial() {
  useEffect(() => {
    const id = decodeURIComponent(window.location.hash.slice(1))
    if (!id) return
    // Espera a que el ResizeObserver haya fijado --alto-cabecera en cada marco.
    const t = window.setTimeout(
      () => document.getElementById(id)?.scrollIntoView(),
      100,
    )
    return () => window.clearTimeout(t)
  }, [])
}

/** Decisión 9: la foto flota dos veces al entrar el ratón y se para. */
function useFotoFlota() {
  useEffect(() => {
    const fotos = [...document.querySelectorAll<HTMLElement>(".inicio .foto")]
    const entrar = (ev: PointerEvent) => {
      const foto = ev.currentTarget as HTMLElement
      if (ev.pointerType !== "mouse" || foto.classList.contains("flotando"))
        return
      if (!window.matchMedia("(hover: hover)").matches) return
      if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return
      foto.classList.add("flotando")
    }
    const terminar = (ev: AnimationEvent) =>
      (ev.currentTarget as HTMLElement).classList.remove("flotando")
    fotos.forEach((f) => {
      f.addEventListener("pointerenter", entrar)
      f.addEventListener("animationend", terminar)
    })
    return () =>
      fotos.forEach((f) => {
        f.removeEventListener("pointerenter", entrar)
        f.removeEventListener("animationend", terminar)
        f.classList.remove("flotando")
      })
  }, [])
}

/** Portada /: lo de /detalles-3 más la Decisión 7. */
function Inicio() {
  useDetalles(true, true)
  useSeccionActual()
  useFotoFlota()
  useAnclaInicial()
  const tema = useTema()
  return (
    <div className="lienzo">
      {marcosPortada.map((m) => (
        <figure key={m.p} className="marco-figura">
          <figcaption>{m.titulo}</figcaption>
          <div
            className="marco con-alma color-d detalles detalles-2 detalles-3 inicio sitio"
            data-tema={tema}
            style={{ width: m.ancho }}
            data-name={`portada-${m.p}`}
          >
            <Portada p={m.p} conVida detalles detalles2 detalles3 inicio />
          </div>
        </figure>
      ))}
    </div>
  )
}

/** /identidad: tokens de diseño en el marco común de la web. */
function IdentidadSitio() {
  useDetalles(true, true)
  const tema = useTema()
  return (
    <div className="lienzo">
      {marcosProyecto.map((m) => (
        <figure key={m.p} className="marco-figura">
          <figcaption>{m.titulo}</figcaption>
          <div
            className="marco con-alma color-d detalles detalles-2 detalles-3 sitio identidad"
            data-tema={tema}
            style={{ width: m.ancho }}
            data-name={`identidad-${m.p}`}
          >
            <Identidad p={m.p} />
          </div>
        </figure>
      ))}
    </div>
  )
}
