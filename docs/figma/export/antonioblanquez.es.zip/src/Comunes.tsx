import {
  useState,
  type ComponentProps,
  type ElementType,
  type ReactNode,
} from "react"
import { navegacion, pie, propietario } from "./contenido"
import { BotonTema } from "./Tema"

/** Bloque con nombre de capa: el nombre del componente y data-name coinciden. */
export function capa<T extends ElementType>(nombre: string, Etiqueta: T) {
  const C = (props: ComponentProps<T>) => {
    const E = Etiqueta as ElementType
    return <E {...props} data-name={nombre} />
  }
  C.displayName = nombre
  return C
}

const Cabecera = capa("cabecera", "header")
const Navegacion = capa("navegacion", "nav")
const NavegacionFinal = capa("navegacion-final", "nav")
const Pie = capa("pie", "footer")
const BarraInferior = capa("barra-inferior", "nav")

/** Iconos de trazo de la barra inferior (Decisión 9). */
const trazo = {
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": true,
} as const
const iconosBarra: Record<string, ReactNode> = {
  proyectos: (
    <svg {...trazo}>
      <rect x="3" y="3" width="7" height="7" rx="1" />
      <rect x="14" y="3" width="7" height="7" rx="1" />
      <rect x="3" y="14" width="7" height="7" rx="1" />
      <rect x="14" y="14" width="7" height="7" rx="1" />
    </svg>
  ),
  "como-trabajo": (
    <svg {...trazo}>
      <path d="m3 5 1.5 1.5L7 4" />
      <path d="m3 12 1.5 1.5L7 11" />
      <path d="m3 19 1.5 1.5L7 18" />
      <path d="M11 5h10M11 12h10M11 19h10" />
    </svg>
  ),
  "sobre-mi": (
    <svg {...trazo}>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </svg>
  ),
  contacto: (
    <svg {...trazo}>
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
    </svg>
  ),
}

/** base: '' en la portada (anclas locales), '/' en otras páginas. */
function ListaNavegacion({
  id,
  p,
  base,
  actual,
}: {
  id?: string
  p: string
  base: string
  actual?: string
}) {
  return (
    <ul className="enlaces-fila" id={id} data-name="lista-navegacion">
      {navegacion.map((n) => (
        <li key={n.ancla}>
          <a
            href={`${base}#${p}-${n.ancla}`}
            className={n.ancla === "contacto" ? "nav-contacto" : undefined}
            aria-current={actual === n.ancla ? "true" : undefined}
          >
            {n.texto}
          </a>
        </li>
      ))}
    </ul>
  )
}

/** p: prefijo para que los id no se repitan entre marcos. */
export function Pagina({
  p,
  base,
  menuAbierto = false,
  inicio = false,
  sitio = false,
  identidad = false,
  children,
  /** Portada /: la firma sube al principio del marco y hay botón «Arriba». */
  /** Marco común de la web (portada y /proyectos/*): barra inferior, «Arriba», sin navegación final. */
  /** /identidad: marco de proyecto sin sección marcada ni «Volver». */
}: {
  p: string
  base: string
  menuAbierto?: boolean
  inicio?: boolean
  sitio?: boolean
  identidad?: boolean
  children: ReactNode
}) {
  const [abierto, setAbierto] = useState(menuAbierto)
  const idMenu = `${p}-menu`
  // En las páginas de proyecto, «Proyectos» queda siempre marcado.
  const actual = sitio && !inicio && !identidad ? "proyectos" : undefined
  return (
    <div className="portada">
      <a
        className="saltar"
        href={`#${p}-contenido`}
        data-name="saltar-al-contenido"
      >
        Saltar al contenido
      </a>
      <Cabecera className="cabecera">
        {sitio && !inicio && !identidad && (
          <a
            className="volver-cabecera"
            href={`/#${p}-proyectos`}
            data-name="volver"
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M19 12H5" />
              <path d="m12 19-7-7 7-7" />
            </svg>
            <span className="sr-only">Volver a proyectos</span>
          </a>
        )}
        <a
          className="nombre"
          href={inicio ? `#${p}-inicio` : "/"}
          data-name="nombre"
        >
          {propietario.nombre}
        </a>
        <Navegacion aria-label="Principal">
          <button
            type="button"
            className="boton-menu"
            aria-expanded={abierto}
            aria-controls={idMenu}
            onClick={() => setAbierto(!abierto)}
            data-name="boton-menu"
          >
            Menú
          </button>
          <div className={abierto ? "menu menu-abierto" : "menu"}>
            <ListaNavegacion id={idMenu} p={p} base={base} actual={actual} />
          </div>
        </Navegacion>
        {sitio && <BotonTema />}
      </Cabecera>

      <main id={`${p}-contenido`} tabIndex={-1} data-name="contenido-principal">
        {sitio && <span className="ancla-inicio" id={`${p}-inicio`} />}
        {children}
      </main>

      {!sitio && (
        <NavegacionFinal className="navegacion-final" aria-label="Secciones">
          <ListaNavegacion p={p} base={base} />
        </NavegacionFinal>
      )}

      <Pie className="pie">
        <p>{pie.copyright}</p>
        <ul className="enlaces-fila">
          {pie.enlaces.map((e) => (
            <li key={e.href}>
              <a href={e.href}>{e.texto}</a>
            </li>
          ))}
        </ul>
      </Pie>

      {sitio && (
        <div className="abajo" data-name="abajo">
          <div className="arriba" data-name="arriba">
            <a href={`#${p}-inicio`}>
              <span className="arriba-texto">Arriba</span>
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d="m5 12 7-7 7 7" />
                <path d="M12 19V5" />
              </svg>
            </a>
          </div>
          <BarraInferior className="barra-inferior" aria-label="Principal">
            <ul>
              {navegacion.map((n) => (
                <li key={n.ancla}>
                  <a
                    href={`${base}#${p}-${n.ancla}`}
                    aria-current={actual === n.ancla ? "true" : undefined}
                  >
                    <span className="pastilla">{iconosBarra[n.ancla]}</span>
                    <span className="nombre-barra">{n.texto}</span>
                  </a>
                </li>
              ))}
            </ul>
          </BarraInferior>
        </div>
      )}
    </div>
  )
}
