import { useEffect, useRef, useState, type CSSProperties } from "react"
import { capa, Pagina } from "./Comunes"
import { MuestraBotonTema } from "./Tema"
import { IconoGitHub, IconoGlobo, IconoLinkedIn } from "./Portada"

const Seccion = capa("identidad", "section")
const capas = {
  colores: capa("colores", "section"),
  tipografia: capa("tipografia", "section"),
  espacios: capa("espacios", "section"),
  esquinas: capa("esquinas", "section"),
  sombras: capa("sombras", "section"),
  movimiento: capa("movimiento", "section"),
  piezas: capa("piezas", "section"),
}

type Color = {
  token: string
  claro: string
  oscuro: string
  uso: string
  fondos?: string[]
  minimo?: number
}
const fondosBase = ["--color-fondo", "--color-superficie", "--color-caja"]
const colores: Color[] = [
  {
    token: "--color-fondo",
    claro: "#F7F5F0",
    oscuro: "#1C1A17",
    uso: "Bandas crema de la portada, pie, fondo del menú y hover del botón neutro",
  },
  {
    token: "--color-superficie",
    claro: "#FFFFFF",
    oscuro: "#26231F",
    uso: "Bandas blancas, tarjetas, botón neutro, cajas de otros proyectos y píldora del dominio",
  },
  {
    token: "--color-caja",
    claro: "#F7F5F0",
    oscuro: "#312D28",
    uso: "Caja neutra (cifras, “Lo que no hace”, galería), barra de la ventana de navegador y etiquetas de tecnologías",
  },
  {
    token: "--color-texto",
    claro: "#1A1A1A",
    oscuro: "#EDEAE4",
    uso: "Texto principal, iconos en reposo y borde del botón neutro en hover",
    fondos: fondosBase,
    minimo: 4.5,
  },
  {
    token: "--color-texto-secundario",
    claro: "#4A4A4A",
    oscuro: "#B8B2A8",
    uso: "Entradilla, línea de datos, etiquetas, pies de foto y nombres de la barra inferior en reposo",
    fondos: fondosBase,
    minimo: 4.5,
  },
  {
    token: "--color-linea",
    claro: "#D9D9D9",
    oscuro: "#4A453E",
    uso: "Bordes y líneas",
  },
  {
    token: "--color-titulo",
    claro: "#6B2410",
    oscuro: "#F0A587",
    uso: "h1, h2 y firma, salvo donde va el color del proyecto",
    fondos: fondosBase,
    minimo: 3,
  },
  {
    token: "--color-acento",
    claro: "#A63D1E",
    oscuro: "#E58B6B",
    uso: "Enlaces, anillo de foco, bordes de acento y nombre de la sección actual en la barra inferior",
    fondos: fondosBase,
    minimo: 4.5,
  },
  {
    token: "--color-acento-relleno",
    claro: "#A63D1E",
    oscuro: "#A63D1E",
    uso: "Botón primario, sección actual del menú y de la barra, círculos de “Decisiones” y caja “Resultado”",
  },
  {
    token: "--color-acento-relleno-hover",
    claro: "#6B2410",
    oscuro: "#6B2410",
    uso: "Fondo del botón primario en hover",
  },
  {
    token: "--color-sobre-acento",
    claro: "#FFFFFF",
    oscuro: "#FFFFFF",
    uso: "Texto e iconos sobre el relleno de acento y raya de “Resultado”",
    fondos: ["--color-acento-relleno"],
    minimo: 4.5,
  },
  {
    token: "--color-resalte",
    claro: "#FBEDE8",
    oscuro: "#3D2A23",
    uso: "Fondo de hover y foco del menú, de la barra inferior, de “Volver” y del botón de tema",
  },
  {
    token: "--color-resalte-texto",
    claro: "#6B2410",
    oscuro: "#F6CDBD",
    uso: "Texto e icono sobre el resalte",
    fondos: ["--color-resalte"],
    minimo: 4.5,
  },
  {
    token: "--color-decoracion",
    claro: "#E58B6B",
    oscuro: "#E58B6B",
    uso: "Aro de la foto. Solo decoración, nunca texto",
  },
  {
    token: "--color-cabecera",
    claro: "rgba(255, 255, 255, 0.9)",
    oscuro: "rgba(38, 35, 31, 0.9)",
    uso: "Cabecera y barra inferior translúcidas",
  },
  {
    token: "--color-logo-terceros",
    claro: "#1A1A1A",
    oscuro: "#FFFFFF",
    uso: "Logos de GitHub y LinkedIn",
  },
  {
    token: "--color-marco-telefono",
    claro: "#1A1A1A",
    oscuro: "#3D3934",
    uso: "Marco del teléfono en tarjetas y composición",
  },
  {
    token: "--color-degradado-inicio",
    claro: "#A63D1E",
    oscuro: "#E58B6B",
    uso: "Inicio del degradado del h1 de la portada",
  },
  {
    token: "--color-degradado-fin",
    claro: "#6B2410",
    oscuro: "#F0A587",
    uso: "Fin del degradado del h1 de la portada",
  },
  {
    token: "--color-proyecto-radiografia",
    claro: "#332288",
    oscuro: "#8E7FEF",
    uso: "Franja, h1, cifras y rayas de RadiografIA",
    fondos: fondosBase,
    minimo: 3,
  },
  {
    token: "--color-proyecto-desplazame",
    claro: "#2563EB",
    oscuro: "#6B9BF5",
    uso: "Franja, h1, cifras y rayas de Desplázame",
    fondos: fondosBase,
    minimo: 3,
  },
  {
    token: "--color-proyecto-zetabus",
    claro: "#7048E8",
    oscuro: "#B48CF7",
    uso: "Franja, h1, cifras y rayas de ZetaBus",
    fondos: fondosBase,
    minimo: 3,
  },
  {
    token: "--color-proyecto-linaje",
    claro: "#0F857D",
    oscuro: "#3FBFB2",
    uso: "Franja, h1, cifras y rayas de Linaje",
    fondos: fondosBase,
    minimo: 3,
  },
  {
    token: "--color-placa-icono",
    claro: "transparent",
    oscuro: "#EDEAE4",
    uso: "Placa detrás de los iconos de proyecto, solo en oscuro",
  },
  {
    token: "--color-lienzo",
    claro: "#F2F2F2",
    oscuro: "#F2F2F2",
    uso: "Fondo gris del modelo, fuera de los marcos. No es de la web",
  },
]

const tamanos = [
  "--tamano-cuerpo",
  "--tamano-pie",
  "--tamano-secundario",
  "--tamano-dominio",
  "--tamano-ficha-valor",
  "--tamano-barra-inferior",
  "--tamano-entradilla",
  "--tamano-nombre-caja",
  "--tamano-nombre-tarjeta",
  "--tamano-h2",
  "--tamano-h1-proyecto",
  "--tamano-h1-portada",
  "--tamano-firma",
  "--tamano-cifra",
  "--tamano-cifra-ficha",
]
const espacios = [
  "--espacio-1",
  "--espacio-2",
  "--espacio-3",
  "--espacio-4",
  "--espacio-5",
  "--espacio-6",
  "--espacio-7",
  "--espacio-8",
]
const radios = [
  "--radio-raya",
  "--radio-boton",
  "--radio-caja",
  "--radio-telefono",
  "--radio-pildora",
  "--radio-circulo",
]
const sombras = [
  "--sombra-tarjeta",
  "--sombra-tarjeta-hover",
  "--sombra-telefono",
  "--sombra-foto",
  "--sombra-boton-flotante",
]
const movimientos: [string, string][] = [
  ["--duracion-rapida", "Hover y foco de enlaces y botones"],
  ["--duracion-media", "Tarjetas y botón Arriba"],
  ["--duracion-zoom", "Zoom de las capturas"],
  ["--duracion-aparicion", "Aparición al hacer scroll"],
  ["--escalon-aparicion", "Retraso entre tarjetas"],
  ["--duracion-flotar", "Foto que flota"],
]

/** Lee el valor que cada token tiene en este marco y en cada tema. */
function useValores(
  ref: React.RefObject<HTMLElement | null>,
  tokens: string[],
  tema?: string,
) {
  const [v, setV] = useState<Record<string, string>>({})
  useEffect(() => {
    const el = tema
      ? ref.current?.querySelector<HTMLElement>(`[data-tema='${tema}']`)
      : ref.current
    if (!el) return
    const cs = getComputedStyle(el)
    setV(
      Object.fromEntries(tokens.map((t) => [t, cs.getPropertyValue(t).trim()])),
    )
  }, [ref, tokens, tema])
  return v
}

const rgb = (s: string) => (s.match(/[\d.]+/g) ?? []).map(Number)
const lum = (s: string) => {
  const [r, g, b] = rgb(s).map((c) => {
    const x = c / 255
    return x <= 0.04045 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4
  })
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}
const ratio = (a: string, b: string) => {
  const [x, y] = [lum(a), lum(b)].sort((m, n) => n - m)
  return (x + 0.05) / (y + 0.05)
}
const nombreFondo: Record<string, string> = {
  "--color-fondo": "fondo",
  "--color-superficie": "superficie",
  "--color-caja": "caja",
  "--color-resalte": "resalte",
  "--color-acento-relleno": "relleno",
}
const coma = (n: number) => n.toFixed(1).replace(".", ",")

/** Contraste vivo: color resuelto con getComputedStyle dentro de cada contenedor temático. */
function Contraste({ c, tema }: { c: Color; tema: "claro" | "oscuro" }) {
  const ref = useRef<HTMLDivElement>(null)
  const [texto, setTexto] = useState("")
  useEffect(() => {
    const raiz = ref.current
    if (!raiz || !c.fondos) return
    const primero = raiz.querySelector<HTMLElement>("i")
    if (!primero) return
    const color = getComputedStyle(primero).color
    let llega = true
    const partes = c.fondos.map((f, i) => {
      const fondo = getComputedStyle(
        raiz.querySelectorAll<HTMLElement>("b")[i],
      ).backgroundColor
      const r = ratio(color, fondo)
      if (r < c.minimo!) llega = false
      return `${nombreFondo[f]} ${coma(r)}:1`
    })
    const marca = !llega
      ? "No llega"
      : c.minimo === 3
        ? "mínimo 3, texto grande"
        : "mínimo 4,5"
    setTexto(`${partes.join(" · ")} · ${marca}`)
  }, [c])
  if (!c.fondos) return <>—</>
  return (
    <span ref={ref} className="contraste">
      <span data-tema={tema} hidden>
        <i style={{ color: `var(${c.token})` }} />
        {c.fondos.map((f) => (
          <b key={f} style={{ backgroundColor: `var(${f})` }} />
        ))}
      </span>
      <span className="contraste-cifras">{texto}</span>
    </span>
  )
}

function Muestra({ token, tema }: { token: string; tema: "claro" | "oscuro" }) {
  return (
    <span className="muestra-tema">
      <span data-tema={tema}>
        <span className="muestra" style={{ background: `var(${token})` }} />
      </span>
      <span className="muestra-etiqueta">
        {tema === "claro" ? "Claro" : "Oscuro"}
      </span>
    </span>
  )
}

function Colores() {
  const C = capas.colores
  return (
    <C className="banda-identidad">
      <div className="columna">
        <h2>Colores</h2>
        <table className="tabla-colores">
          <thead>
            <tr>
              <th scope="col">Muestra</th>
              <th scope="col">Token</th>
              <th scope="col">Claro</th>
              <th scope="col">Oscuro</th>
              <th scope="col">Uso</th>
              <th scope="col">Contraste</th>
            </tr>
          </thead>
          <tbody>
            {colores.map((c) => (
              <tr key={c.token}>
                <td data-titulo="Muestra" className="muestras">
                  <Muestra token={c.token} tema="claro" />
                  <Muestra token={c.token} tema="oscuro" />
                </td>
                <th scope="row" data-titulo="Token">
                  <code>{c.token}</code>
                </th>
                <td data-titulo="Claro">
                  <code>{c.claro}</code>
                </td>
                <td data-titulo="Oscuro">
                  <code>{c.oscuro}</code>
                </td>
                <td data-titulo="Uso">{c.uso}</td>
                <td data-titulo="Contraste">
                  {c.fondos ? (
                    <span className="contrastes">
                      <span>
                        Claro: <Contraste c={c} tema="claro" />
                      </span>
                      <span>
                        Oscuro: <Contraste c={c} tema="oscuro" />
                      </span>
                    </span>
                  ) : (
                    "—"
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </C>
  )
}

function Lista({
  nombre,
  titulo,
  tokens,
  muestra,
}: {
  nombre: keyof typeof capas
  titulo: string
  tokens: string[]
  muestra: (t: string, v: string) => React.ReactNode
}) {
  const C = capas[nombre]
  const ref = useRef<HTMLElement>(null)
  const v = useValores(ref, tokens)
  return (
    <C className="banda-identidad" ref={ref}>
      <div className="columna">
        <h2>{titulo}</h2>
        <ul className="lista-tokens" role="list">
          {tokens.map((t) => (
            <li key={t}>
              <code>{t}</code>
              <span className="valor">{v[t]}</span>
              {muestra(t, v[t] ?? "")}
            </li>
          ))}
        </ul>
      </div>
    </C>
  )
}

function Sombras() {
  const C = capas.sombras
  const ref = useRef<HTMLElement>(null)
  const claro = useValores(ref, sombras, "claro")
  const oscuro = useValores(ref, sombras, "oscuro")
  return (
    <C className="banda-identidad" ref={ref}>
      <div className="columna">
        <h2>Sombras</h2>
        <span data-tema="claro" hidden />
        <span data-tema="oscuro" hidden />
        <ul className="lista-tokens" role="list">
          {sombras.map((t) => (
            <li key={t}>
              <code>{t}</code>
              <span className="valor">
                Claro: <code>{claro[t]}</code>
                <br />
                Oscuro: <code>{oscuro[t]}</code>
              </span>
              <span
                className="muestra-sombra"
                style={{ boxShadow: `var(${t})` }}
              />
            </li>
          ))}
        </ul>
      </div>
    </C>
  )
}

function Movimiento() {
  const C = capas.movimiento
  const ref = useRef<HTMLElement>(null)
  const v = useValores(
    ref,
    movimientos.map(([t]) => t),
  )
  return (
    <C className="banda-identidad" ref={ref}>
      <div className="columna">
        <h2>Movimiento</h2>
        <ul className="lista-tokens" role="list">
          {movimientos.map(([t, uso]) => (
            <li key={t}>
              <code>{t}</code>
              <span className="valor">{v[t]}</span>
              <span>{uso}</span>
            </li>
          ))}
        </ul>
      </div>
    </C>
  )
}

function Pieza({
  nombre,
  children,
}: {
  nombre: string
  children: React.ReactNode
}) {
  return (
    <li className="pieza">
      <code>{nombre}</code>
      <div className="pieza-muestra">{children}</div>
    </li>
  )
}

function Piezas() {
  const C = capas.piezas
  const inerte = (e: React.MouseEvent) => e.preventDefault()
  return (
    <C className="banda-identidad">
      <div className="columna">
        <h2>Piezas</h2>
        <ul className="lista-piezas" role="list">
          <Pieza nombre=".boton-primario">
            <span className="botones-tarjeta">
              <a className="boton-primario" href="#" onClick={inerte}>
                <IconoGlobo />
                En vivo
              </a>
            </span>
          </Pieza>
          <Pieza nombre=".boton-secundario">
            <span className="botones-tarjeta">
              <a
                className="boton-secundario boton-marca"
                href="#"
                onClick={inerte}
              >
                <IconoGitHub />
                Código
              </a>
            </span>
          </Pieza>
          <Pieza nombre=".boton-cuadrado">
            <span className="botones-tarjeta">
              <a
                className="boton-secundario boton-marca boton-cuadrado"
                href="#"
                onClick={inerte}
              >
                <IconoLinkedIn />
                <span className="sr-only">LinkedIn</span>
              </a>
            </span>
          </Pieza>
          <Pieza nombre=".etiquetas li">
            <ul className="etiquetas" role="list">
              <li>TypeScript</li>
            </ul>
          </Pieza>
          {(["reposo", "hover", "foco", "actual"] as const).map((e) => (
            <Pieza
              key={e}
              nombre={`.menu a · ${e === "actual" ? "sección actual" : e}`}
            >
              <span className="menu-muestra">
                <a
                  className={`enlace-menu estado-${e}`}
                  href="#"
                  onClick={inerte}
                  aria-current={e === "actual" ? "true" : undefined}
                >
                  Proyectos
                </a>
              </span>
            </Pieza>
          ))}
          {(["reposo", "actual"] as const).map((e) => (
            <Pieza
              key={e}
              nombre={`.barra-inferior .pastilla · ${
                e === "actual" ? "sección actual" : e
              }`}
            >
              <span className={`pastilla-muestra estado-${e}`}>
                <span className="pastilla">
                  <svg
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <rect x="3" y="3" width="7" height="7" rx="1" />
                    <rect x="14" y="3" width="7" height="7" rx="1" />
                    <rect x="3" y="14" width="7" height="7" rx="1" />
                    <rect x="14" y="14" width="7" height="7" rx="1" />
                  </svg>
                </span>
                <span className="nombre-barra">Proyectos</span>
              </span>
            </Pieza>
          ))}
          <Pieza nombre=".tarjeta-nohace">
            <div className="caja-muestra tarjeta-nohace">
              <p className="texto">[texto pendiente]</p>
            </div>
          </Pieza>
          <Pieza nombre=".tarjeta-resultado">
            <div className="caja-muestra tarjeta-resultado">
              <p className="texto">[texto pendiente]</p>
            </div>
          </Pieza>
          <Pieza nombre="h2 · raya">
            <p className="h2-muestra">Título de sección</p>
          </Pieza>
          <Pieza nombre=".decision-numero">
            <span className="decision-numero">1</span>
          </Pieza>
          <Pieza nombre=".boton-tema">
            <MuestraBotonTema />
          </Pieza>
        </ul>
      </div>
    </C>
  )
}

export default function Identidad({ p }: { p: string }) {
  return (
    <Pagina p={p} base="/" sitio identidad>
      <Seccion className="banda-identidad cabecera-identidad">
        <div className="columna">
          <h1>Identidad visual</h1>
        </div>
      </Seccion>
      <Colores />
      <Lista
        nombre="tipografia"
        titulo="Tipografía"
        tokens={tamanos}
        muestra={(t) => (
          <span
            className={
              t === "--tamano-firma" ? "muestra-texto firma" : "muestra-texto"
            }
            style={{ fontSize: `var(${t})` } as CSSProperties}
          >
            Antonio Blánquez
          </span>
        )}
      />
      <Lista
        nombre="espacios"
        titulo="Espacios"
        tokens={espacios}
        muestra={(t) => (
          <span className="barra-espacio" style={{ width: `var(${t})` }} />
        )}
      />
      <Lista
        nombre="esquinas"
        titulo="Esquinas"
        tokens={radios}
        muestra={(t) => (
          <span
            className="muestra-esquina"
            style={{ borderRadius: `var(${t})` }}
          />
        )}
      />
      <Sombras />
      <Movimiento />
      <Piezas />
    </Pagina>
  )
}
