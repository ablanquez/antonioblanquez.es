import type React from "react"
import { capa, Pagina } from "./Comunes"
import {
  paginasProyecto,
  proyectos,
  type PaginaProyectoDatos,
  type Proyecto,
} from "./contenido"
import { IconoGitHub, IconoGlobo } from "./Portada"

const PresentacionProyecto = capa("presentacion-proyecto", "section")
const FichaProyecto = capa("ficha-proyecto", "section")
const Captura = capa("captura", "div")
const Bloque = capa("bloque-proyecto", "section")

const Volver = capa("volver", "div")
const Entrada = capa("entrada", "section")
const DatosProyecto = capa("datos-proyecto", "dl")
const Cifras = capa("cifras", "div")
const Composicion = capa("composicion", "div")
const PresentacionSitio = capa("presentacion-proyecto", "div")
const MasCapturas = capa("mas-capturas", "section")
const OtrosProyectos = capa("otros-proyectos", "section")

const bloquesSitio: {
  titulo: string
  fondo: string
  clave: keyof PaginaProyectoDatos["bloques"]
}[] = [
  { titulo: "Por qué existe", fondo: "gris", clave: "queEs" },
  { titulo: "Decisiones", fondo: "blanco", clave: "decisiones" },
  { titulo: "Cómo lo comprobé", fondo: "gris", clave: "comprobe" },
  { titulo: "Lo que no hace", fondo: "blanco", clave: "noHace" },
  { titulo: "Resultado", fondo: "gris", clave: "resultado" },
  { titulo: "Qué haría distinto", fondo: "blanco", clave: "distinto" },
]

const flecha = (d: string) => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <path d={d} />
  </svg>
)

/** Decisión 10: página de proyecto con el marco común de la web. */
function ContenidoSitio({ p, proyecto }: { p: string; proyecto: Proyecto }) {
  const i = proyectos.findIndex((pr) => pr.slug === proyecto.slug)
  const anterior = proyectos[(i - 1 + proyectos.length) % proyectos.length]
  const siguiente = proyectos[(i + 1) % proyectos.length]
  const pendiente = "[texto pendiente]"
  const pagina = paginasProyecto[
    proyecto.slug
  ] as PaginaProyectoDatos | undefined
  const tecnologias = pagina?.tecnologias ?? []
  const icono = (d: string[]) => (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {d.map((x) => (
        <path key={x} d={x} />
      ))}
    </svg>
  )
  const datos: [string, string, string[]][] = [
    [
      "Fecha",
      pagina?.fecha ?? pendiente,
      [
        "M8 2v4",
        "M16 2v4",
        "M3 10h18",
        "M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z",
      ],
    ],
    ["Estado", pagina?.estado ?? pendiente, ["M22 12h-4l-3 9L9 3l-3 9H2"]],
    [
      "Versión",
      pagina?.version ?? pendiente,
      [
        "M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",
        "M7.5 7.5h.01",
      ],
    ],
  ]
  const dominio = new URL(proyecto.enVivo).hostname
  const cifras = pagina?.cifras ?? []
  const parrafos = (
    clave: keyof PaginaProyectoDatos["bloques"],
    aparece: boolean,
  ) =>
    (pagina?.bloques[clave] ?? [pendiente]).map((t, i) => (
      <p key={i} className={aparece ? "texto aparece" : "texto"}>
        {t}
      </p>
    ))
  return (
    <>
      <Entrada className="entrada">
        <Volver className="volver">
          <a href={`/#${p}-proyectos`}>
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M19 12H5" />
              <path d="m12 19-7-7 7-7" />
            </svg>
            Volver a proyectos
          </a>
        </Volver>

        <Composicion className="composicion">
          <div className="ventana" data-name="ventana-navegador">
            <div className="ventana-barra" data-name="barra-navegador">
              <span className="ventana-puntos" aria-hidden="true">
                <span />
                <span />
                <span />
              </span>
              <span className="ventana-dominio">{dominio}</span>
            </div>
            <div className="composicion-zona" data-name="captura-proyecto">
              <img
                className="composicion-escritorio"
                src={proyecto.captura.src}
                alt={proyecto.captura.alt}
              />
              <div className="marco-movil" data-name="captura-movil">
                <img src={`/capturas/movil-${proyecto.slug}.png`} alt="" />
              </div>
            </div>
          </div>
        </Composicion>

        <PresentacionSitio className="cabecera-proyecto columna">
          <div
            className="franja"
            style={{ background: `var(--color-proyecto-${proyecto.slug})` }}
            data-name="franja-proyecto"
          />
          <ul className="etiquetas" role="list" aria-label="Tecnologías">
            {tecnologias.length === 0 ? (
              <li>{pendiente}</li>
            ) : (
              tecnologias.map((t) => <li key={t}>{t}</li>)
            )}
          </ul>
          <div className="titulo-con-icono" data-name="titulo-proyecto">
            <img
              className="icono"
              src={proyecto.icono}
              alt=""
              width={48}
              height={48}
              data-name="icono-proyecto"
            />
            <h1 style={{ color: `var(--color-proyecto-${proyecto.slug})` }}>
              {proyecto.nombre}
            </h1>
          </div>
          <DatosProyecto
            className="datos-proyecto"
            aria-label="Datos del proyecto"
          >
            {datos.map(([t, d, ic]) => (
              <div key={t}>
                <dt className="sr-only">{t}</dt>
                <dd>
                  {icono(ic)}
                  {d}
                </dd>
              </div>
            ))}
          </DatosProyecto>
          <p className="entradilla">{proyecto.texto}</p>
          <ul
            className="botones-tarjeta"
            role="list"
            data-name="botones-proyecto"
          >
            <li>
              <a className="boton-primario" href={proyecto.enVivo}>
                <IconoGlobo />
                {proyecto.etiquetaEnVivo}
              </a>
            </li>
            <li>
              <a
                className="boton-secundario boton-marca"
                href={proyecto.codigo}
              >
                <IconoGitHub />
                Código
              </a>
            </li>
          </ul>
        </PresentacionSitio>
      </Entrada>

      {bloquesSitio.map((b) => (
        <Bloque
          key={b.titulo}
          className={`bloque-sitio fondo-${b.fondo} bloque-${b.clave}`}
          style={
            {
              "--raya": `var(--color-proyecto-${proyecto.slug})`,
            } as React.CSSProperties
          }
        >
          {b.clave === "noHace" || b.clave === "resultado" ? (
            <div
              className={`columna tarjeta-bloque aparece ${
                b.clave === "resultado" ? "tarjeta-resultado" : "tarjeta-nohace"
              }`}
            >
              <h2>{b.titulo}</h2>
              {parrafos(b.clave, false)}
            </div>
          ) : (
            <div className="columna">
              <h2>{b.titulo}</h2>
              {b.clave === "decisiones" ? (
                <ol
                  className="lista-decisiones"
                  role="list"
                  data-name="decisiones"
                >
                  {(pagina?.bloques.decisiones ?? [pendiente]).map((t, i) => (
                    <li key={i} className="aparece">
                      <span className="decision-numero" aria-hidden="true">
                        {i + 1}
                      </span>
                      <p className="texto">{t}</p>
                    </li>
                  ))}
                </ol>
              ) : (
                <>
                  {b.clave === "comprobe" && (
                    <Cifras className="tarjeta-cifras aparece">
                      <ul role="list">
                        {cifras.map((c) => (
                          <li key={c.etiqueta}>
                            <span
                              className="cifra-valor"
                              style={{
                                color: `var(--color-proyecto-${proyecto.slug})`,
                              }}
                            >
                              {c.valor}
                            </span>
                            <span className="cifra-etiqueta">{c.etiqueta}</span>
                          </li>
                        ))}
                      </ul>
                    </Cifras>
                  )}
                  {parrafos(b.clave, true)}
                </>
              )}
            </div>
          )}
        </Bloque>
      ))}

      <MasCapturas
        className="mas-capturas"
        style={
          {
            "--raya": `var(--color-proyecto-${proyecto.slug})`,
          } as React.CSSProperties
        }
      >
        <h2>Más capturas</h2>
        <div className="galeria aparece" data-name="galeria">
          <div className="huecos">
            {[0, 1].map((n) => {
              const c = pagina?.masCapturas[n]
              return c ? (
                <figure key={n} className="figura-captura" data-name="captura">
                  <div className="hueco">
                    <img src={c.src} alt={c.alt} loading="lazy" />
                  </div>
                  <figcaption>{c.pie}</figcaption>
                </figure>
              ) : (
                <div key={n} className="hueco" data-name="captura-pendiente">
                  [captura pendiente]
                </div>
              )
            })}
          </div>
        </div>
      </MasCapturas>

      <OtrosProyectos className="otros-proyectos">
        <nav aria-label="Más proyectos">
          <ul>
            {[
              {
                pr: anterior,
                texto: "Proyecto anterior",
                clase: "caja-anterior",
              },
              {
                pr: siguiente,
                texto: "Proyecto siguiente",
                clase: "caja-siguiente",
              },
            ].map(({ pr, texto, clase }) => (
              <li key={clase}>
                <a
                  className={`caja-proyecto ${clase}`}
                  href={`/proyectos/${pr.slug}`}
                  data-name={
                    clase === "caja-anterior"
                      ? "proyecto-anterior"
                      : "proyecto-siguiente"
                  }
                >
                  <span className="caja-etiqueta">
                    {clase === "caja-anterior" &&
                      flecha("M19 12H5m7 7-7-7 7-7")}
                    {texto}
                    {clase === "caja-siguiente" &&
                      flecha("M5 12h14m-7-7 7 7-7 7")}
                  </span>
                  <span className="caja-nombre">
                    <img
                      className="icono"
                      src={pr.icono}
                      alt=""
                      width={24}
                      height={24}
                    />
                    <span style={{ color: `var(--color-proyecto-${pr.slug})` }}>
                      {pr.nombre}
                    </span>
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </OtrosProyectos>
    </>
  )
}

const bloques = [
  "El problema",
  "La solución",
  "Decisiones",
  "Cómo lo comprobé",
  "Resultado",
  "Qué haría distinto",
]

export default function PaginaProyecto({
  p,
  proyecto,
  conVida = false,
  sitio = false,
  /** Solo en /con-vida: captura real en lugar del hueco. */
  /** /proyectos/*: página de la Decisión 10 con el marco común de la web. */
}: {
  p: string
  proyecto: Proyecto
  conVida?: boolean
  sitio?: boolean
}) {
  if (sitio)
    return (
      <Pagina p={p} base="/" sitio>
        <ContenidoSitio p={p} proyecto={proyecto} />
      </Pagina>
    )
  const datos = [
    ["Rol", "[texto pendiente]"],
    ["Tecnología", proyecto.tecnologia],
    ["Fecha", "[texto pendiente]"],
  ]
  return (
    <Pagina p={p} base="/">
      <div className="columna-proyecto">
        <PresentacionProyecto className="presentacion">
          <div
            className="franja"
            style={{ background: `var(--color-proyecto-${proyecto.slug})` }}
            data-name="franja-proyecto"
          />
          <div className="titulo-con-icono" data-name="titulo-proyecto">
            <img
              className="icono"
              src={proyecto.icono}
              alt=""
              width={48}
              height={48}
              data-name="icono-proyecto"
            />
            <h1>{proyecto.nombre}</h1>
          </div>
          <p className="texto">{proyecto.texto}</p>
        </PresentacionProyecto>

        <FichaProyecto className="ficha" aria-label="Ficha del proyecto">
          <dl>
            {datos.map(([t, d]) => (
              <div key={t}>
                <dt>{t}</dt>
                <dd>{d}</dd>
              </div>
            ))}
          </dl>
          <ul className="enlaces-fila">
            <li>
              <a href={proyecto.enVivo}>{proyecto.etiquetaEnVivo}</a>
            </li>
            <li>
              <a href={proyecto.codigo}>Código</a>
            </li>
          </ul>
        </FichaProyecto>

        <section>
          {conVida ? (
            <img
              className="captura-real"
              src={proyecto.captura.src}
              alt={proyecto.captura.alt}
              data-name="captura"
            />
          ) : (
            <Captura className="captura">[captura pendiente]</Captura>
          )}
        </section>

        {bloques.map((b) => (
          <Bloque key={b}>
            <h2>{b}</h2>
            <p className="texto">[texto pendiente]</p>
          </Bloque>
        ))}
      </div>
    </Pagina>
  )
}
